﻿using UnityEngine;
using System.Collections;

public class tree1 : MonoBehaviour {

		// Use this for initialization
	void Start () {
		 Transform  tr = GetComponent< Transform >();
		 // Debug.Log("transform is "+tr.position); 	 
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
