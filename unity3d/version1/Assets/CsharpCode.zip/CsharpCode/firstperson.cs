﻿using UnityEngine;
using System.Collections;
using System.Net.Sockets;
using System.Net;
public class firstperson : MonoBehaviour {
	private Socket S;
 	private int port=4800;
	private float liftforce= 19.9f;
	private float resistance=1.05f;
	private int lastcom=-1;
	private CharacterMotor Motor;
	private float speed=10.0f;
	private int length=20;
	private int framenumber=0;
	private int longlength=50;
	private float step=2.0f;
	  
	private int smooth=-1;
	private float range= 15f;
	private float uprange=80f;
	private int freeze=0;
	private MouseLook Look;
	private int []commandist={0,-1,-1,-1,-1,-1,3,3,3,3,3,-1,-1,-1,-1};
	private int commandindex=-1;
	// Use this for initialization
	void Start () {
		port=4800;
		connect ();
		Vector3 liftvelocity = Vector3.zero;
		Look =this.GetComponent<MouseLook>();
		Motor=this.GetComponent<CharacterMotor>();		 
					liftvelocity.y = liftforce * Time.deltaTime;
		 Vector3 CurrentV=  this.GetComponent<CharacterMotor>().movement.velocity;
		 this.GetComponent<CharacterMotor>().movement.velocity=CurrentV+liftvelocity;
	}
	
	// Update is called once per frame
	void Update(){}
	
	  void OnCollisionEnter(Collision collision) {
        foreach (ContactPoint contact in collision.contacts) {
             
        }
        Debug.Log("collision:"+transform.position);
        
    }
	void smoothmodify(){
		Debug.Log("last com:"+lastcom+":|freeze:"+freeze+" "+Look.transform.eulerAngles);
		switch (lastcom)
		{
		   case 1: //left
			
			if(freeze<0)
			{
				//transform.Rotate(0,  -10f, 0);
				if(this.smooth*step<this.range)
				{
				  

					Vector3 rotate=Vector3.zero;
					rotate.z=step;
					Look.transform.Rotate(rotate);
				    smooth++;
				}else{
					freeze=this.length;
				}
			}
			break;
		   case 2: //right
				if(freeze<0)
			{
				if(this.smooth*step<this.range)
				{
					Vector3 rotate=Vector3.zero;
					rotate.z=(0-step);
					Look.transform.Rotate(rotate);
				    smooth++;
				}else{
					freeze=this.length;
				}
			}
			break;
		   case 3: 
				if(freeze<0)
			{
				if(this.smooth*step<this.uprange)
				{
				
				Look.camerarotateup(this.step);
				smooth++;
				}else{
					freeze=this.longlength;
				}
			}
			break;
		   default:
				//freeze=0;
			break;
			
		}
	 
		if(freeze>0)
		{
			freeze--;
			 
		}else{
			if(freeze==0)
			{	
				//Look.cameraback();
				 
		    
			Vector3 Angles=Look.transform.localEulerAngles; 
			float ax=0f,az=0f;
			if(Angles.x<=180f)
				ax=Mathf.Max(0f, Angles.x-this.step);
			else	
				ax=Mathf.Min( Angles.x+this.step,360f);
			if(Angles.z<=180f)
				az=Mathf.Max(0f,Angles.z-this.step);
			else
				az=Mathf.Min (360f,Angles.z+this.step);
			
			Vector3 newa=Vector3.zero;
			newa.x=ax;
			newa.z=az;
			Look.transform.localEulerAngles=newa;/**/
			}
		}		
	
	
		
	}
	void FixedUpdate () {
				   Debug.Log ("current:"+Motor.movement.velocity+": normal"+Motor.groundNormal+"groundis"+Motor.grounded);
		//Debug.Log("collision"+this.collider);
		          Vector3 CurrentV=  this.GetComponent<CharacterMotor>().movement.velocity;
		          CharacterController controller = GetComponent<CharacterController>();
		           Vector3 liftvelocity = Vector3.zero;
					 
					liftvelocity.y = liftforce * Time.deltaTime;
		smoothmodify();
		
		if(CurrentV.y<0.1)
		{ 
			float vupward=liftvelocity.y+CurrentV.y;
			if(vupward>0)
				liftvelocity.y=0-CurrentV.y-0.001f;
			this.GetComponent<CharacterMotor>().movement.velocity=CurrentV+liftvelocity;
		}
		  if (!this.Motor.grounded)
		 {	 
				//Debug.Log("ground normal:"+Motor.groundNormal);
							CurrentV=Motor.movement.velocity;
							 Vector3 forwardvelocity = Vector3.zero;				 
					         forwardvelocity.z = resistance * Time.deltaTime;
							 if(CurrentV.z <forwardvelocity.z)
								CurrentV.z=0;
							else 
								CurrentV=CurrentV-forwardvelocity;  
							 Motor.movement.velocity=CurrentV;
		 }else{
			Debug.Log("land on game over");
				 Motor.movement.velocity=Vector3.zero;
				Debug.Log(transform.position);
		}
			
       			// controller.Move(moveDirection );
		 
				int command=-1;
				byte[] message = new byte[256];
				byte[] buffer=new byte[1];
				int offset=0;
				if(S.Available>25){
					        while(S.Available>0)
							{ 	
								int messagel =S.Receive(buffer); 
 								if( System.Convert.ToChar(buffer[0])=='\n')
							 		break;
								else
									{	
										message[offset]=buffer[0];
										offset++;
									}
								
							}
						 

				}
			if(offset>0){
					string result = System.Text.Encoding.UTF8.GetString(message,0,offset);
				 	Debug.Log("command:"+result);	
					 
			        commandindex++;
					if(commandindex>this.commandist.Length)
						command=-1;
					else
						command=commandist[commandindex];
					 lastcom=command;
				 
					
			 		 
					//parse command
				}
		Vector3 movedire=Vector3.zero;
		Vector3 newspeed=Vector3.zero;
			switch(command)
			{
				case 0://jump-flying;
				{
			         bool on=this.Motor.onthetree;
					if(on)
					{ 			Debug.Log("Jumping");
					  
					//CharacterController controller = GetComponent<CharacterController>();
					Vector3 jumpDirection=this.transform.forward;
						jumpDirection.y=0;
						jumpDirection=jumpDirection.normalized;
					  Debug.Log("direction forward:"+this.transform.forward);
					  Motor.movement.velocity=jumpDirection*this.speed;
			    	  Motor.onthetree=false;
					}
          			  //this.rigidbody.velocity = this.transform.forward*10;
			
					

				}
					break;
				case 1://turn left
					{	
					Debug.Log("left");
					freeze= -1;
					smooth=0;
					   movedire=this.transform.forward;
			 //Debug.Log("time:"+Time.deltaTime);
					// this.GetComponent<MouseLook>().camerarotateleft(30f);
					this.framenumber=5*this.length;
					transform.Rotate(0,  -10f, 0);
			 
					Vector3 d=transform.forward;
					newspeed=Vector3.Project( Motor.movement.velocity,d);
					Motor.movement.velocity=newspeed;
					}
					break;
				case 2://turn right
					 {
					freeze= -1;
					smooth=0;
					movedire=this.transform.forward;
					//this.framenumber=this.length+range/step+2;
					transform.Rotate(0,  10f, 0);
					Vector3 d=transform.forward;
					newspeed=Vector3.Project( Motor.movement.velocity,d);
					Motor.movement.velocity=newspeed;
					//this.GetComponent<MouseLook>().camerarotateright();
					 }
					break;
				case 3: //climbing tree
					{
					     bool on=this.Motor.onthetree;
						 if(on)
						 {
									
									smooth=0;
									freeze=0;
									//Motor.movement.velocity.y=20f;
									//this.GetComponent<MouseLook>().camerarotateup();
									//framenumber=this.longlength;
									Debug.Log(" to up");
						 }else{
				
						}
						
					}break;
				default: break;
			}
				/* if (BitConverter.IsLittleEndian)
    				Array.Reverse(bytes);

				int i = BitConverter.ToInt32(bytes, 0);*/
		
	}
	
	void connect(){
		 
		 S = new System.Net.Sockets.Socket( System.Net.Sockets.AddressFamily.InterNetwork, 
   		 System.Net.Sockets.SocketType.Stream, System.Net.Sockets.ProtocolType.Tcp);
		 IPHostEntry ipHostInfo = Dns.Resolve(Dns.GetHostName());
            IPAddress ipAddress = ipHostInfo.AddressList[0];
            IPEndPoint remoteEP = new IPEndPoint(ipAddress,port);
		  S.Connect(remoteEP);
		 
		Debug.Log("Socket connected to"+S.RemoteEndPoint.ToString());
		 //s.Available;
	}
}
